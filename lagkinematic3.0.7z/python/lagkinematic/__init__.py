"""
LAGKINEMATIC 3.0
Python controller + C++ kernels for Lagrangian trajectory integration.
Author: Jacopo Busatto, Luigi Palatella & Guglielmo Lacorata
"""
__version__ = "3.0.0"