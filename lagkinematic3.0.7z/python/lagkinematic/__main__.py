from .cli import main

if __name__ == "__main__":
    # delega al click CLI
    main(standalone_mode=True)
