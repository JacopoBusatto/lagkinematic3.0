# python/lagkinematic/fields/mask_regular_latlon.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Union

import numpy as np
import xarray as xr


NumberOrArray = Union[float, np.ndarray]


@dataclass
class RegularLatLonMaskConfig:
    data_path: str
    lon_name: str = "lon"
    lat_name: str = "lat"
    u_name: str = "uo"
    v_name: str = "vo"
    time_name: Optional[str] = "time"
    depth_name: Optional[str] = None
    speed_min: float = 0.0  # >0 = mare, <=0 o NaN = terra


class RegularLatLonMaskSampler:
    """
    Maschera statica terra/mare su griglia regolare lat/lon.

    Costruita dal primo file NetCDF del dominio (primo tempo, primo livello).
    Criterio: speed = hypot(u, v); se speed finite & > speed_min -> 1.0 (mare), altrimenti 0.0 (terra).
    """

    def __init__(self, cfg: RegularLatLonMaskConfig):
        self.cfg = cfg

        # Apriamo il dataset solo per costruire la maschera, poi lo chiudiamo
        with xr.open_dataset(cfg.data_path) as ds:
            u = ds[cfg.u_name]
            v = ds[cfg.v_name]

            # Se c'è dimensione tempo, prendiamo il primo indice
            if cfg.time_name and cfg.time_name in u.dims:
                u = u.isel({cfg.time_name: 0})
                v = v.isel({cfg.time_name: 0})

            # Se c'è profondità, prendiamo il primo livello (superficie)
            if cfg.depth_name and cfg.depth_name in u.dims:
                u = u.isel({cfg.depth_name: 0})
                v = v.isel({cfg.depth_name: 0})

            speed = np.hypot(u, v)

            # mask = 1.0 mare, 0.0 terra / invalid
            mask = xr.where(np.isfinite(speed) & (speed > cfg.speed_min), 1.0, 0.0)

            # Salviamo solo la maschera con coordinate lon/lat
            self._mask = mask
            self._lon_name = cfg.lon_name
            self._lat_name = cfg.lat_name

    def sample_mask(self, lon: NumberOrArray, lat: NumberOrArray) -> NumberOrArray:
        """
        Restituisce il valore della maschera interpolato in (lon, lat).
        lon, lat possono essere float o array NumPy 1D.
        """
        # Usa interpolazione lineare sulle due dimensioni → bilineare
        da = self._mask.interp(
            {
                self._lon_name: lon,
                self._lat_name: lat,
            },
            method="linear",
        )

        # Qualsiasi NaN fuori dal dominio la consideriamo terra
        da_filled = da.fillna(0.0)

        values = da_filled.values

        # Se è uno scalare NumPy, convertiamolo in float Python
        if np.isscalar(values):
            return float(values)
        return values.astype(float)

    @classmethod
    def from_velocity_config(cls, vel_cfg: dict, mask_cfg: dict) -> "RegularLatLonMaskSampler":
        """
        Helper: costruisce la maschera riusando la config del campo di velocità.
        """
        cfg = RegularLatLonMaskConfig(
            data_path=vel_cfg["dataset"],
            lon_name=vel_cfg.get("lon_name", "lon"),
            lat_name=vel_cfg.get("lat_name", "lat"),
            u_name=vel_cfg.get("u_name", "uo"),
            v_name=vel_cfg.get("v_name", "vo"),
            time_name=vel_cfg.get("time_name", "time"),
            depth_name=vel_cfg.get("depth_name"),  # può essere None
            speed_min=mask_cfg.get("speed_min", 0.0),
        )
        return cls(cfg)
