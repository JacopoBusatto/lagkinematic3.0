# python/lagkinematic/sampling/__init__.py
from .regular_latlon import RegularLatLonSampler

__all__ = ["RegularLatLonSampler"]